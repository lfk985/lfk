package cn.itcast.day11.demo02;

public class MyAnother {

    public void anotherMethod() {
//        System.out.println(new MyClass().num);
    }

}
