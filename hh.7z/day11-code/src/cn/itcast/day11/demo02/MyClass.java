package cn.itcast.day11.demo02;

public class MyClass {

    public int num = 10;

    public void method() {
        System.out.println(num);
    }

}
