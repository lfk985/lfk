package cn.itcast.day11.demo05;

public interface MyInterface {

    void method1(); // 抽象方法

    void method2();

}
