package cn.itcast.day11.demo01;

// 不能使用一个final类来作为父类
public class MySubClass /*extends MyClass*/ {
}
